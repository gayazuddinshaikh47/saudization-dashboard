# Saudization Overview Dashboard (Sample Data)

## Project overview
This portfolio project demonstrates an HR analytics workflow: preparing a sample employee dataset, calculating Saudi employee representation by department, and presenting the results in a dashboard.

> **Important:** This is a practice project. Nationality values are synthetic and do not represent real workforce demographics. The 25% threshold is illustrative only and is **not** an official Nitaqat rule or a compliance assessment.

## Business question
How can a dashboard help compare Saudi employee representation across departments and highlight departments below a selected example threshold for further review?

## Dataset
- `sample_hr_data.csv` — the smaller dataset used for the analysis
- `cleaned_hr_data.xlsx` — working Excel workbook
- `department_summary.csv` — department-level counts and percentages

The practice dataset contains 1,470 rows. It includes department, job title, hire date, nationality labels, and calculated percentage/status fields. The nationality labels are synthetic.

## Method
1. Review and clean the employee records in Excel.
2. Count Saudi and Non-Saudi labels by department.
3. Calculate Saudi percentage as Saudi employees divided by total employees.
4. Apply a configurable example threshold (25%) for an illustrative status flag.
5. Visualize the KPIs and department comparison in Power BI.

## Key sample results
- Total records: **1,470**
- Records labeled Saudi: **417**
- Records labeled Non-Saudi: **1,053**
- Overall sample Saudi percentage: **28.4%**
- Departments below the 25% example threshold: **0**

Department-level results:
- Human Resources: 16/63 labeled Saudi (25.4%)
- Research & Development: 275/961 labeled Saudi (28.6%)
- Sales: 126/446 labeled Saudi (28.3%)

## Dashboard
See `dashboard_overview.png` for the dashboard preview. If you use Power BI, open Power BI Desktop and select **Home → Get data → Excel workbook** to import the workbook, then build or refresh the report visuals.

`saudization_dashboard_excel.xlsx` is an Excel workbook, **not** a native Power BI `.pbix` file. If you create a `.pbix` file in Power BI Desktop, add it to this repository only after checking that it opens correctly.

## Tools
- Microsoft Excel
- Microsoft Power BI Desktop
- GitHub

## Limitations and responsible use
This is synthetic practice data and should not be used for staffing, legal, or regulatory decisions. The example threshold does not represent an official Nitaqat requirement. Actual requirements vary according to applicable rules and establishment classification. Do not upload real employee personal information or confidential company data.

## Files
- `sample_hr_data.csv`
- `cleaned_hr_data.xlsx`
- `department_summary.csv`
- `saudization_dashboard_excel.xlsx`
- `dashboard_overview.png`
- `Saudization_Project_Summary.docx`
- `Saudization_Project_Summary.pdf`
- `linkedin_post.txt`
- `consultant_outreach.txt`
